package com.bahao.websocket.entity;


import lombok.Data;

@Data
public class Greeting {

    private String content;
    private String userId;

}
