package com.bahao.websocket.ctrl;

import com.alibaba.fastjson.JSONObject;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Test {
    @GetMapping("get")
    public JSONObject getUser() {
        JSONObject obj = new JSONObject();
        obj.put("data", "测试跨域问题");
        //  simpMessageSendingOperations.convertAndSend("/topic/group", obj);
        return obj;
    }
}
